<?php
    include "comps/header.php";
    include "comps/Home.php";
    pageHeader();


    homePage();




    pageFooter()

?>